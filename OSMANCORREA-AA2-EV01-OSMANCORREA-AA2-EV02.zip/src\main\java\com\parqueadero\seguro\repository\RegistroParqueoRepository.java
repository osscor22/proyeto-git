package com.parqueadero.seguro.repository;

import com.parqueadero.seguro.model.RegistroParqueo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

/**
 * Repositorio JPA para operaciones CRUD sobre la tabla registros_parqueo.
 */
@Repository
public interface RegistroParqueoRepository extends JpaRepository<RegistroParqueo, Long> {

    List<RegistroParqueo> findByEstado(RegistroParqueo.EstadoRegistro estado);
    Optional<RegistroParqueo> findByVehiculo_PlacaAndEstado(String placa, RegistroParqueo.EstadoRegistro estado);
    List<RegistroParqueo> findAllByOrderByHoraIngresoDesc();
}
