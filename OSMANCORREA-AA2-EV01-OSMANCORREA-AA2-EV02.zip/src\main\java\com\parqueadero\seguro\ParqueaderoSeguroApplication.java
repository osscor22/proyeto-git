package com.parqueadero.seguro;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Clase principal de la aplicación Spring Boot.
 * Punto de entrada del Backend "Parqueadero Seguro".
 */
@SpringBootApplication
public class ParqueaderoSeguroApplication {

    public static void main(String[] args) {
        SpringApplication.run(ParqueaderoSeguroApplication.class, args);
        System.out.println("=== Parqueadero Seguro Backend Iniciado ===");
    }
}
