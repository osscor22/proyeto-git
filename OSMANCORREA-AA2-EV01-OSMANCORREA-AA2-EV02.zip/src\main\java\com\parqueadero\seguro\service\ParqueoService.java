package com.parqueadero.seguro.service;

import com.parqueadero.seguro.model.*;
import com.parqueadero.seguro.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Servicio principal que contiene toda la lógica de negocio
 * del parqueadero: ingreso de vehículos, salida, liquidación
 * de tarifas y gestión de celdas.
 */
@Service
@RequiredArgsConstructor
public class ParqueoService {

    private final VehiculoRepository vehiculoRepository;
    private final CeldaRepository celdaRepository;
    private final RegistroParqueoRepository registroRepository;
    private final TarifaRepository tarifaRepository;

    /**
     * Registra la ENTRADA de un vehículo al parqueadero.
     * 1. Busca o crea el vehículo por placa.
     * 2. Busca la primera celda disponible del tipo correspondiente.
     * 3. Marca la celda como OCUPADA.
     * 4. Crea un RegistroParqueo con estado ACTIVO.
     */
    @Transactional
    public RegistroParqueo registrarIngreso(String placa, Celda.TipoVehiculo tipo) {
        // Verificar si el vehículo ya tiene un registro activo
        registroRepository.findByVehiculo_PlacaAndEstado(placa, RegistroParqueo.EstadoRegistro.ACTIVO)
                .ifPresent(r -> {
                    throw new RuntimeException("El vehículo con placa " + placa + " ya se encuentra dentro del parqueadero (Celda: " + r.getCelda().getNumero() + ")");
                });

        // Buscar o crear el vehículo
        Vehiculo vehiculo = vehiculoRepository.findByPlaca(placa)
                .orElseGet(() -> vehiculoRepository.save(
                        Vehiculo.builder().placa(placa).tipo(tipo).build()
                ));

        // Buscar celda disponible del tipo de vehículo
        Celda celda = celdaRepository.findByEstado(Celda.EstadoCelda.DISPONIBLE)
                .stream()
                .filter(c -> c.getTipo() == tipo)
                .findFirst()
                .orElseThrow(() -> new RuntimeException("No hay celdas disponibles para " + tipo));

        // Obtener tarifa vigente
        Tarifa tarifa = tarifaRepository.findByTipoVehiculo(tipo)
                .orElseThrow(() -> new RuntimeException("No existe tarifa configurada para " + tipo));

        // Marcar celda como ocupada
        celda.setEstado(Celda.EstadoCelda.OCUPADA);
        celdaRepository.save(celda);

        // Crear el registro de parqueo
        RegistroParqueo registro = RegistroParqueo.builder()
                .vehiculo(vehiculo)
                .celda(celda)
                .horaIngreso(LocalDateTime.now())
                .tarifaHora(tarifa.getValorHora())
                .estado(RegistroParqueo.EstadoRegistro.ACTIVO)
                .build();

        return registroRepository.save(registro);
    }

    /**
     * Registra la SALIDA de un vehículo y calcula el cobro.
     * 1. Busca el registro activo por placa.
     * 2. Calcula el tiempo transcurrido.
     * 3. Liquida el total a cobrar.
     * 4. Marca la celda como DISPONIBLE.
     * 5. Actualiza el registro con estado FINALIZADO.
     */
    @Transactional
    public RegistroParqueo registrarSalida(String placa, RegistroParqueo.MetodoPago metodoPago) {
        RegistroParqueo registro = registroRepository
                .findByVehiculo_PlacaAndEstado(placa, RegistroParqueo.EstadoRegistro.ACTIVO)
                .orElseThrow(() -> new RuntimeException("No se encontró un vehículo activo con placa: " + placa));

        LocalDateTime ahora = LocalDateTime.now();
        Duration duracion = Duration.between(registro.getHoraIngreso(), ahora);
        long minutos = duracion.toMinutes();

        // Calcular horas (redondeando hacia arriba si hay fracción)
        BigDecimal horas = BigDecimal.valueOf(minutos)
                .divide(BigDecimal.valueOf(60), 2, RoundingMode.CEILING);

        // Total = horas * tarifa por hora
        BigDecimal total = horas.multiply(registro.getTarifaHora())
                .setScale(0, RoundingMode.CEILING);

        // Actualizar registro
        registro.setHoraSalida(ahora);
        registro.setTotalCobrado(total);
        registro.setEstado(RegistroParqueo.EstadoRegistro.FINALIZADO);
        registro.setMetodoPago(metodoPago);

        // Liberar la celda
        Celda celda = registro.getCelda();
        celda.setEstado(Celda.EstadoCelda.DISPONIBLE);
        celdaRepository.save(celda);

        return registroRepository.save(registro);
    }

    /**
     * Obtiene todos los registros activos (vehículos dentro del parqueadero).
     */
    public List<RegistroParqueo> obtenerRegistrosActivos() {
        return registroRepository.findByEstado(RegistroParqueo.EstadoRegistro.ACTIVO);
    }

    /**
     * Obtiene el historial completo de registros ordenados por fecha descendente.
     */
    public List<RegistroParqueo> obtenerHistorial() {
        return registroRepository.findAllByOrderByHoraIngresoDesc();
    }
}
