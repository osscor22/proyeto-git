package com.parqueadero.seguro.repository;

import com.parqueadero.seguro.model.Celda;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

/**
 * Repositorio JPA para operaciones CRUD sobre la tabla celdas.
 */
@Repository
public interface CeldaRepository extends JpaRepository<Celda, Long> {

    Optional<Celda> findByNumero(String numero);
    List<Celda> findByEstado(Celda.EstadoCelda estado);
    List<Celda> findByTipo(Celda.TipoVehiculo tipo);
    long countByEstado(Celda.EstadoCelda estado);
}
