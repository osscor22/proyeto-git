package com.parqueadero.seguro.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Entidad JPA que representa un registro transaccional
 * de entrada/salida de un vehículo en el parqueadero.
 */
@Entity
@Table(name = "registros_parqueo")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RegistroParqueo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "vehiculo_id", nullable = false)
    private Vehiculo vehiculo;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "celda_id", nullable = false)
    private Celda celda;

    @Column(name = "hora_ingreso", nullable = false)
    private LocalDateTime horaIngreso;

    @Column(name = "hora_salida")
    private LocalDateTime horaSalida;

    @Column(name = "tarifa_hora", nullable = false, precision = 10, scale = 2)
    private BigDecimal tarifaHora;

    @Column(name = "total_cobrado", precision = 10, scale = 2)
    private BigDecimal totalCobrado;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EstadoRegistro estado = EstadoRegistro.ACTIVO;

    @Enumerated(EnumType.STRING)
    @Column(name = "metodo_pago")
    private MetodoPago metodoPago;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        if (horaIngreso == null) {
            horaIngreso = LocalDateTime.now();
        }
    }

    public enum EstadoRegistro {
        ACTIVO, FINALIZADO
    }

    public enum MetodoPago {
        EFECTIVO, APP, TARJETA
    }
}
