package com.parqueadero.seguro.controller;

import com.parqueadero.seguro.model.Usuario;
import com.parqueadero.seguro.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Controlador REST para la gestión de usuarios
 * (operadores, administradores, clientes).
 *
 * Base URL: /api/usuarios
 */
@RestController
@RequestMapping("/api/usuarios")
@RequiredArgsConstructor
public class UsuarioController {

    private final UsuarioRepository usuarioRepository;

    /**
     * GET /api/usuarios
     * Retorna la lista completa de usuarios registrados.
     */
    @GetMapping
    public ResponseEntity<List<Usuario>> listarUsuarios() {
        return ResponseEntity.ok(usuarioRepository.findAll());
    }

    /**
     * POST /api/usuarios
     * Crea un nuevo usuario en el sistema.
     */
    @PostMapping
    public ResponseEntity<?> crearUsuario(@RequestBody Usuario usuario) {
        if (usuarioRepository.existsByUsername(usuario.getUsername())) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "El username '" + usuario.getUsername() + "' ya existe"));
        }
        if (usuarioRepository.existsByDocumento(usuario.getDocumento())) {
            return ResponseEntity.badRequest()
                    .body(Map.of("error", "El documento '" + usuario.getDocumento() + "' ya está registrado"));
        }
        return ResponseEntity.ok(usuarioRepository.save(usuario));
    }

    /**
     * POST /api/usuarios/login
     * Verifica credenciales (autenticación básica, sin JWT).
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body) {
        String username = body.get("username");
        String password = body.get("password");

        return usuarioRepository.findByUsername(username)
                .filter(u -> u.getPassword().equals(password) && u.getActivo())
                .map(u -> {
                    Map<String, Object> response = Map.of(
                            "mensaje", "Inicio de sesión exitoso",
                            "usuario", u.getNombre(),
                            "rol", u.getRol()
                    );
                    return ResponseEntity.ok((Object) response);
                })
                .orElse(ResponseEntity.status(401)
                        .body(Map.of("error", "Credenciales incorrectas o usuario inactivo")));
    }
}
