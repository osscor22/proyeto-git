package com.parqueadero.seguro.repository;

import com.parqueadero.seguro.model.Celda;
import com.parqueadero.seguro.model.Tarifa;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Repositorio JPA para operaciones CRUD sobre la tabla tarifas.
 */
@Repository
public interface TarifaRepository extends JpaRepository<Tarifa, Long> {

    Optional<Tarifa> findByTipoVehiculo(Celda.TipoVehiculo tipoVehiculo);
}
