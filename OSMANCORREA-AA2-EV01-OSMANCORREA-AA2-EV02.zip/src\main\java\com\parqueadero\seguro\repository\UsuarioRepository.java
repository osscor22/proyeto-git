package com.parqueadero.seguro.repository;

import com.parqueadero.seguro.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Repositorio JPA para operaciones CRUD sobre la tabla usuarios.
 */
@Repository
public interface UsuarioRepository extends JpaRepository<Usuario, Long> {

    Optional<Usuario> findByUsername(String username);
    Optional<Usuario> findByDocumento(String documento);
    boolean existsByUsername(String username);
    boolean existsByDocumento(String documento);
}
