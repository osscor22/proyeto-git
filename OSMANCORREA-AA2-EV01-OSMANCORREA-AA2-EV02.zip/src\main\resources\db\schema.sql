-- ============================================================
-- Base de Datos: parqueadero_seguro
-- Motor: MySQL 8.x
-- Descripción: Script DDL para la creación de la base de datos
-- y las tablas necesarias para la aplicación web
-- "Parqueadero Seguro" (Proyecto SENA - ADSO)
-- ============================================================

CREATE DATABASE IF NOT EXISTS parqueadero_seguro
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE parqueadero_seguro;

-- --------------------------
-- Tabla: usuarios
-- Almacena operadores y clientes
-- --------------------------
CREATE TABLE usuarios (
    id          BIGINT       AUTO_INCREMENT PRIMARY KEY,
    nombre      VARCHAR(100) NOT NULL,
    documento   VARCHAR(20)  NOT NULL UNIQUE,
    email       VARCHAR(100),
    telefono    VARCHAR(20),
    username    VARCHAR(50)  NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,
    rol         ENUM('ADMIN', 'OPERADOR', 'CLIENTE') NOT NULL DEFAULT 'CLIENTE',
    activo      BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- --------------------------
-- Tabla: celdas
-- Representa cada espacio físico del parqueadero
-- --------------------------
CREATE TABLE celdas (
    id          BIGINT       AUTO_INCREMENT PRIMARY KEY,
    numero      VARCHAR(10)  NOT NULL UNIQUE,
    tipo        ENUM('AUTOMOVIL', 'MOTOCICLETA') NOT NULL DEFAULT 'AUTOMOVIL',
    estado      ENUM('DISPONIBLE', 'OCUPADA', 'MANTENIMIENTO') NOT NULL DEFAULT 'DISPONIBLE',
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- --------------------------
-- Tabla: vehiculos
-- Información registrada de cada vehículo
-- --------------------------
CREATE TABLE vehiculos (
    id          BIGINT       AUTO_INCREMENT PRIMARY KEY,
    placa       VARCHAR(10)  NOT NULL UNIQUE,
    tipo        ENUM('AUTOMOVIL', 'MOTOCICLETA') NOT NULL DEFAULT 'AUTOMOVIL',
    marca       VARCHAR(50),
    color       VARCHAR(30),
    usuario_id  BIGINT,
    created_at  TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_vehiculo_usuario FOREIGN KEY (usuario_id)
        REFERENCES usuarios(id) ON DELETE SET NULL
);

-- --------------------------
-- Tabla: registros_parqueo
-- Tabla transaccional principal: cada entrada y salida
-- --------------------------
CREATE TABLE registros_parqueo (
    id              BIGINT       AUTO_INCREMENT PRIMARY KEY,
    vehiculo_id     BIGINT       NOT NULL,
    celda_id        BIGINT       NOT NULL,
    hora_ingreso    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    hora_salida     DATETIME     NULL,
    tarifa_hora     DECIMAL(10,2) NOT NULL,
    total_cobrado   DECIMAL(10,2) NULL,
    estado          ENUM('ACTIVO', 'FINALIZADO') NOT NULL DEFAULT 'ACTIVO',
    metodo_pago     ENUM('EFECTIVO', 'APP', 'TARJETA') NULL,
    created_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_registro_vehiculo FOREIGN KEY (vehiculo_id)
        REFERENCES vehiculos(id) ON DELETE CASCADE,
    CONSTRAINT fk_registro_celda FOREIGN KEY (celda_id)
        REFERENCES celdas(id) ON DELETE CASCADE
);

-- --------------------------
-- Tabla: tarifas
-- Almacena la configuración de tarifas vigentes
-- --------------------------
CREATE TABLE tarifas (
    id              BIGINT       AUTO_INCREMENT PRIMARY KEY,
    tipo_vehiculo   ENUM('AUTOMOVIL', 'MOTOCICLETA') NOT NULL UNIQUE,
    valor_hora      DECIMAL(10,2) NOT NULL,
    cobro_fraccion  BOOLEAN      NOT NULL DEFAULT TRUE,
    updated_at      TIMESTAMP    DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ============================================================
-- Datos iniciales de ejemplo
-- ============================================================

-- Usuario administrador por defecto
INSERT INTO usuarios (nombre, documento, email, username, password, rol)
VALUES ('Administrador', '000000', 'admin@parksecure.co', 'admin', 'admin123', 'ADMIN');

-- Tarifas base
INSERT INTO tarifas (tipo_vehiculo, valor_hora, cobro_fraccion) VALUES
('AUTOMOVIL', 3000.00, TRUE),
('MOTOCICLETA', 1500.00, TRUE);

-- Celdas de automóviles (C01 a C20)
INSERT INTO celdas (numero, tipo, estado) VALUES
('C01','AUTOMOVIL','DISPONIBLE'), ('C02','AUTOMOVIL','DISPONIBLE'),
('C03','AUTOMOVIL','DISPONIBLE'), ('C04','AUTOMOVIL','DISPONIBLE'),
('C05','AUTOMOVIL','DISPONIBLE'), ('C06','AUTOMOVIL','DISPONIBLE'),
('C07','AUTOMOVIL','DISPONIBLE'), ('C08','AUTOMOVIL','DISPONIBLE'),
('C09','AUTOMOVIL','DISPONIBLE'), ('C10','AUTOMOVIL','DISPONIBLE'),
('C11','AUTOMOVIL','DISPONIBLE'), ('C12','AUTOMOVIL','DISPONIBLE'),
('C13','AUTOMOVIL','DISPONIBLE'), ('C14','AUTOMOVIL','DISPONIBLE'),
('C15','AUTOMOVIL','DISPONIBLE'), ('C16','AUTOMOVIL','DISPONIBLE'),
('C17','AUTOMOVIL','DISPONIBLE'), ('C18','AUTOMOVIL','DISPONIBLE'),
('C19','AUTOMOVIL','DISPONIBLE'), ('C20','AUTOMOVIL','DISPONIBLE');

-- Celdas de motocicletas (M01 a M10)
INSERT INTO celdas (numero, tipo, estado) VALUES
('M01','MOTOCICLETA','DISPONIBLE'), ('M02','MOTOCICLETA','DISPONIBLE'),
('M03','MOTOCICLETA','DISPONIBLE'), ('M04','MOTOCICLETA','DISPONIBLE'),
('M05','MOTOCICLETA','DISPONIBLE'), ('M06','MOTOCICLETA','DISPONIBLE'),
('M07','MOTOCICLETA','DISPONIBLE'), ('M08','MOTOCICLETA','DISPONIBLE'),
('M09','MOTOCICLETA','DISPONIBLE'), ('M10','MOTOCICLETA','DISPONIBLE');
