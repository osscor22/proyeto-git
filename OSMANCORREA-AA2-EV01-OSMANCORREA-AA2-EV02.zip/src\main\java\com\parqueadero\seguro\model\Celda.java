package com.parqueadero.seguro.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import java.time.LocalDateTime;

/**
 * Entidad JPA que representa una celda o espacio
 * físico dentro del parqueadero.
 */
@Entity
@Table(name = "celdas")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Celda {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El número de celda es obligatorio")
    @Column(nullable = false, unique = true, length = 10)
    private String numero;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TipoVehiculo tipo = TipoVehiculo.AUTOMOVIL;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EstadoCelda estado = EstadoCelda.DISPONIBLE;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
    }

    public enum EstadoCelda {
        DISPONIBLE, OCUPADA, MANTENIMIENTO
    }

    public enum TipoVehiculo {
        AUTOMOVIL, MOTOCICLETA
    }
}
