package com.parqueadero.seguro.controller;

import com.parqueadero.seguro.model.Tarifa;
import com.parqueadero.seguro.repository.TarifaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controlador REST para la consulta y actualización
 * de las tarifas vigentes del parqueadero.
 *
 * Base URL: /api/tarifas
 */
@RestController
@RequestMapping("/api/tarifas")
@RequiredArgsConstructor
public class TarifaController {

    private final TarifaRepository tarifaRepository;

    /**
     * GET /api/tarifas
     * Retorna todas las tarifas vigentes.
     */
    @GetMapping
    public ResponseEntity<List<Tarifa>> listarTarifas() {
        return ResponseEntity.ok(tarifaRepository.findAll());
    }

    /**
     * PUT /api/tarifas/{id}
     * Actualiza una tarifa existente.
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarTarifa(@PathVariable Long id, @RequestBody Tarifa tarifaActualizada) {
        return tarifaRepository.findById(id)
                .map(tarifa -> {
                    tarifa.setValorHora(tarifaActualizada.getValorHora());
                    tarifa.setCobroFraccion(tarifaActualizada.getCobroFraccion());
                    return ResponseEntity.ok(tarifaRepository.save(tarifa));
                })
                .orElse(ResponseEntity.notFound().build());
    }
}
