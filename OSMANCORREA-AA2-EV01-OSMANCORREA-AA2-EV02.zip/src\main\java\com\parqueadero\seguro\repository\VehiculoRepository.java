package com.parqueadero.seguro.repository;

import com.parqueadero.seguro.model.Vehiculo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

/**
 * Repositorio JPA para operaciones CRUD sobre la tabla vehiculos.
 */
@Repository
public interface VehiculoRepository extends JpaRepository<Vehiculo, Long> {

    Optional<Vehiculo> findByPlaca(String placa);
    boolean existsByPlaca(String placa);
}
