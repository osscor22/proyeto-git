package com.parqueadero.seguro.controller;

import com.parqueadero.seguro.model.Celda;
import com.parqueadero.seguro.model.RegistroParqueo;
import com.parqueadero.seguro.service.ParqueoService;
import com.parqueadero.seguro.repository.CeldaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Controlador REST principal para la gestión del parqueadero.
 * Expone los endpoints de la API para el ingreso, salida,
 * consulta de celdas e historial de registros.
 *
 * Base URL: /api/parqueo
 */
@RestController
@RequestMapping("/api/parqueo")
@RequiredArgsConstructor
public class ParqueoController {

    private final ParqueoService parqueoService;
    private final CeldaRepository celdaRepository;

    // ============================================================
    // ENDPOINTS DE INGRESO Y SALIDA
    // ============================================================

    /**
     * POST /api/parqueo/ingreso
     * Registra la entrada de un vehículo al parqueadero.
     *
     * Body: { "placa": "XYZ-123", "tipo": "AUTOMOVIL" }
     */
    @PostMapping("/ingreso")
    public ResponseEntity<?> registrarIngreso(@RequestBody Map<String, String> body) {
        try {
            String placa = body.get("placa").toUpperCase().trim();
            Celda.TipoVehiculo tipo = Celda.TipoVehiculo.valueOf(
                    body.getOrDefault("tipo", "AUTOMOVIL").toUpperCase()
            );
            RegistroParqueo registro = parqueoService.registrarIngreso(placa, tipo);

            Map<String, Object> response = new HashMap<>();
            response.put("mensaje", "Vehículo registrado correctamente");
            response.put("placa", registro.getVehiculo().getPlaca());
            response.put("celda", registro.getCelda().getNumero());
            response.put("horaIngreso", registro.getHoraIngreso());
            response.put("tarifaHora", registro.getTarifaHora());
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /**
     * POST /api/parqueo/salida
     * Registra la salida de un vehículo y liquida el cobro.
     *
     * Body: { "placa": "XYZ-123", "metodoPago": "EFECTIVO" }
     */
    @PostMapping("/salida")
    public ResponseEntity<?> registrarSalida(@RequestBody Map<String, String> body) {
        try {
            String placa = body.get("placa").toUpperCase().trim();
            RegistroParqueo.MetodoPago metodo = RegistroParqueo.MetodoPago.valueOf(
                    body.getOrDefault("metodoPago", "EFECTIVO").toUpperCase()
            );
            RegistroParqueo registro = parqueoService.registrarSalida(placa, metodo);

            Map<String, Object> response = new HashMap<>();
            response.put("mensaje", "Salida registrada correctamente");
            response.put("placa", registro.getVehiculo().getPlaca());
            response.put("celda", registro.getCelda().getNumero());
            response.put("horaIngreso", registro.getHoraIngreso());
            response.put("horaSalida", registro.getHoraSalida());
            response.put("totalCobrado", registro.getTotalCobrado());
            response.put("metodoPago", registro.getMetodoPago());
            return ResponseEntity.ok(response);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // ============================================================
    // ENDPOINTS DE CONSULTA
    // ============================================================

    /**
     * GET /api/parqueo/celdas
     * Retorna la lista completa de celdas con su estado actual.
     */
    @GetMapping("/celdas")
    public ResponseEntity<List<Celda>> obtenerCeldas() {
        return ResponseEntity.ok(celdaRepository.findAll());
    }

    /**
     * GET /api/parqueo/activos
     * Retorna los registros de vehículos actualmente dentro del parqueadero.
     */
    @GetMapping("/activos")
    public ResponseEntity<List<RegistroParqueo>> obtenerActivos() {
        return ResponseEntity.ok(parqueoService.obtenerRegistrosActivos());
    }

    /**
     * GET /api/parqueo/historial
     * Retorna el historial completo de registros (entradas y salidas).
     */
    @GetMapping("/historial")
    public ResponseEntity<List<RegistroParqueo>> obtenerHistorial() {
        return ResponseEntity.ok(parqueoService.obtenerHistorial());
    }

    /**
     * GET /api/parqueo/estadisticas
     * Retorna un resumen con estadísticas del parqueadero.
     */
    @GetMapping("/estadisticas")
    public ResponseEntity<Map<String, Object>> obtenerEstadisticas() {
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalCeldas", celdaRepository.count());
        stats.put("celdasDisponibles", celdaRepository.countByEstado(Celda.EstadoCelda.DISPONIBLE));
        stats.put("celdasOcupadas", celdaRepository.countByEstado(Celda.EstadoCelda.OCUPADA));
        stats.put("vehiculosActivos", parqueoService.obtenerRegistrosActivos().size());
        return ResponseEntity.ok(stats);
    }
}
